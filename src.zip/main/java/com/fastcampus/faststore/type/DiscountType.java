package com.fastcampus.faststore.type;

public enum DiscountType {
    AMOUNT,
    PERCENT
}
