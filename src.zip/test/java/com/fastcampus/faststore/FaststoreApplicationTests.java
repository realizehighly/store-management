package com.fastcampus.faststore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FaststoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
